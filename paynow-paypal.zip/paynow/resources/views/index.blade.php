<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completed Paypent</title>
</head>
<body align="center">
    <h1>
        Payment has been done successfully.
    </h1>
    <br>
    @foreach($data as $key)
    <!-- <table> -->
        <tbody>
            <tr>
                <!-- <td>{{ $key->where('parent', 0); }}</td> -->
                <!-- <br><br> -->
                <th><h3>Shipping Order Detaile</h3>
                <td><b>Vendor Id :</b> {{ $key[0]['vendorid']; }}</td><br>
                <td><b>Status :</b> {{ $key[0]['status']; }}</td><br>
                <td><b>Name To ship :</b> {{ $key[0]['nametoship']; }}</td><br>
                <td><b>Address :</b> {{ $key[0]['address']; }}</td><br>
                <td><b>Postal Code :</b> {{ $key[0]['postal_code']; }}</td><br>
                <td><b>Country Code :</b> {{ $key[0]['country_code']; }}</td><br>
                <td><b>Currency Code :</b> {{ $key[0]['currency_code']; }}</td><br>
                <td><b>Amount :</b> {{ $key[0]['amount']; }}</td><br>
            </tr>
        </tbody>
    <!-- </table> -->
        @endforeach
    <br>
    <a href="{{ route('createTransaction') }}">Go Back</a>
</body>
</html>