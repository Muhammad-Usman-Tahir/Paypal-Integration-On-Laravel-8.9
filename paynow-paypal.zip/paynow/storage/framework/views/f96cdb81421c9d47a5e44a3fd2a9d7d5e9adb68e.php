<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completed Paypent</title>
</head>
<body align="center">
    <h1>
        Payment has been done successfully.
    </h1>
    <br>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- <table> -->
        <tbody>
            <tr>
                <!-- <td><?php echo e($key->where('parent', 0)); ?></td> -->
                <!-- <br><br> -->
                <th><h3>Shipping Order Detaile</h3>
                <td><b>Vendor Id :</b> <?php echo e($key[0]['vendorid']); ?></td><br>
                <td><b>Status :</b> <?php echo e($key[0]['status']); ?></td><br>
                <td><b>Name To ship :</b> <?php echo e($key[0]['nametoship']); ?></td><br>
                <td><b>Address :</b> <?php echo e($key[0]['address']); ?></td><br>
                <td><b>Postal Code :</b> <?php echo e($key[0]['postal_code']); ?></td><br>
                <td><b>Country Code :</b> <?php echo e($key[0]['country_code']); ?></td><br>
                <td><b>Currency Code :</b> <?php echo e($key[0]['currency_code']); ?></td><br>
                <td><b>Amount :</b> <?php echo e($key[0]['amount']); ?></td><br>
            </tr>
        </tbody>
    <!-- </table> -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <a href="<?php echo e(route('createTransaction')); ?>">Go Back</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\paynow\resources\views/index.blade.php ENDPATH**/ ?>