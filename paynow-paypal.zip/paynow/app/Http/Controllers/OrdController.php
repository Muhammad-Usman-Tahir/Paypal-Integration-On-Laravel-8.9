<?php
namespace App\Http\Controllers;
use App\Models\Orders;
use Illuminate\Http\Request;
class OrdController extends Controller
{
/**
* Display a listing of the resource.
*
* @return \Illuminate\Http\Response
*/
public function index()
{
    $data['ord'] = Orders::orderBy('id','desc')->paginate(1);
    return view('index',['data'=>$data]);

}
/**
* Show the form for creating a new resource.
*
* @return \Illuminate\Http\Response
*/
public function create()
{
    return view('ord.create');
}
/**
* Store a newly created resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @return \Illuminate\Http\Response
*/
public function store(Request $request)
{
    // return $request;
    // ["purchase_units"][0]["shipping"]["name"]["full_name"];
    $ord = new Orders;
    $ord->title = "";
    $ord->body = "";
    $ord->vendorid = $request["id"];
    $ord->status = $request["status"];
    $ord->nametoship = $request["purchase_units"][0]["shipping"]["name"]["full_name"];
    $ord->address = $request["purchase_units"][0]["shipping"]["address"]["address_line_1"];
    $ord->postal_code = $request["purchase_units"][0]["shipping"]["address"]["postal_code"];
    $ord->country_code = $request["purchase_units"][0]["shipping"]["address"]["country_code"];
    $ord->currency_code = $request["purchase_units"][0]["payments"]["captures"][0]["amount"]["currency_code"];
    $ord->amount = $request["purchase_units"][0]["payments"]["captures"][0]["amount"]["value"];

$ord->save();
return redirect()->route('ord.index')
->with('success','Company has been created successfully.');
}
/**
* Display the specified resource.
*
* @param  \App\ord  $company
* @return \Illuminate\Http\Response
*/
public function show(Orders $ord)
{
return view('ord.show',compact('ord'));
} 
/**
* Show the form for editing the specified resource.
*
* @param  \App\Orders  $company
* @return \Illuminate\Http\Response
*/
public function edit(Orders $ord)
{
return view('ord.edit',compact('ord'));
}
/**
* Update the specified resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @param  \App\ord  $company
* @return \Illuminate\Http\Response
*/
public function update(Request $request, $id)
{
$request->validate([
    'name' => 'required',
    'email' => 'required',
    'address' => 'required',
    ]);
$ord = Orders::find($id);
$ord->name = $request->name;
$ord->email = $request->email;
$ord->address = $request->address;
$ord->save();
return redirect()->route('ord.index')
->with('success','Company Has Been updated successfully');
}
/**
* Remove the specified resource from storage.
*
* @param  \App\Company  $company
* @return \Illuminate\Http\Response
*/
public function destroy(Orders $ord)
{
$ord->delete();
return redirect()->route('ord.index')
->with('success','Company has been deleted successfully');
}
}